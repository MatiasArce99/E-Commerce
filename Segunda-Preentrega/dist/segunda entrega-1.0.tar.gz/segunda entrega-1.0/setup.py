from setuptools import setup

setup(
    
    name='Segunda entrega',
    version = '1.0',
    description = 'Paquete redistribuible',
    author = 'Matías Arce',
    packages = ['paquete1']
    
)